package com.kh.chap3_map.practice.run;

import com.kh.chap3_map.practice.view.MemberMenu;

public class Run {
	public static void main(String[] args) {
		new MemberMenu().mainMenu();
	}
}
