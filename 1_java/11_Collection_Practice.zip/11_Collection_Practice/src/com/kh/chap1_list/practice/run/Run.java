package com.kh.chap1_list.practice.run;

import com.kh.chap1_list.practice.view.MusicView;

public class Run {
	public static void main(String[] args) {
		new MusicView().mainMenu();
	}
}
