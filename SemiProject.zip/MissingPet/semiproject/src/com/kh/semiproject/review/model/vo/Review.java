package com.kh.semiproject.review.model.vo;

public class Review {

}
