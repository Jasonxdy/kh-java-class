package com.kh.semiproject.board.model.service;

import static com.kh.semiproject.common.JDBCTemplate.*;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import com.kh.semiproject.board.model.dao.BoardDao;
import com.kh.semiproject.board.model.vo.Animal;
import com.kh.semiproject.board.model.vo.Attachment;
import com.kh.semiproject.board.model.vo.Board;
import com.kh.semiproject.member.model.vo.Member;

/**
 * @author 정미경
 *
 */
public class BoardService {
	
	/** 전체 게시글 수 조회 Service
	 * @return listCount
	 * @throws Exception
	 */
	public int getListCount(int boardType) throws Exception{
		Connection conn = getConnection();
		
		int listCount = new BoardDao().getListCount(conn, boardType);
		
		close(conn);
		
		return listCount;
	}
	
	/** 게시판 목록 조회용 Service
	 * @param currentPage
	 * @param limit
	 * @return bList
	 * @throws Exception
	 */
	public List<Board> selectFList(int currentPage, int limit, int boardType) throws Exception {
		Connection conn = getConnection();
		
		List<Board> bList = new BoardDao().selectFList(conn, currentPage, limit, boardType);
		
		close(conn);
		
		return bList;
	}

	/** 썸네일 이미지 목록 조회 Service
	 * @param currentPage
	 * @param limit
	 * @return aList
	 * @throws Exception
	 */
	public List<Attachment> selectAList(int currentPage, int limit, int boardType) throws Exception {
		Connection conn = getConnection();
		
		List<Attachment> aList = new BoardDao().selectAList(conn, currentPage, limit, boardType);
		
		close(conn);
		return aList;
	}

	/** 목록 조회용 동물 정보 반환 Service
	 * @param currentPage
	 * @param limit
	 * @param boardType
	 * @return animalList
	 * @throws Exception
	 */
	public List<Animal> selectAnimalList(int currentPage, int limit, int boardType) throws Exception {
		Connection conn = getConnection();
		
		List<Animal> animalList = new BoardDao().selectAnimalList(conn, currentPage, limit, boardType);
		
		close(conn);
		return animalList;
	}

	/** 게시글 상세 조회용 Service
	 * @param boardNo
	 * @return board
	 * @throws Exception
	 */
	public Board selectBoard(int boardNo) throws Exception {
		Connection conn = getConnection();
		
		BoardDao boardDao = new BoardDao();
		
		Board board = boardDao.selectboard(conn, boardNo);
		
		close(conn);
		
		return board;
	}
	
	/** 게시글 이미지 파일 조회용 Service
	 * @param boardNo
	 * @return files
	 * @throws Exception
	 */
	public List<Attachment> selectFiles(int boardNo) throws Exception {
		Connection conn = getConnection();
		
		List<Attachment> files = new BoardDao().selectFiles(conn, boardNo);
		
		close(conn);
		
		return files;
	}

	/** 게시글 동물 조회용 Serivce
	 * @param animalCode
	 * @return animal
	 * @throws Exception
	 */
	public Animal selectAnimal(int animalCode) throws Exception {
		Connection conn = getConnection();
		
		Animal animal = new BoardDao().selectAnimal(conn, animalCode);
		
		close(conn);
		
		return animal;
	}

	/** 게시판 수정화면용 Service
	 * @param no
	 * @return board
	 * @throws Exception
	 */
	public Board updateForm(int no) throws Exception {
		Connection conn = getConnection();
		
		Board board = new BoardDao().selectboard(conn, no);
		
		board.setBoardContent(board.getBoardContent().replace("<br>", "\r\n"));
		
		return board;
	}

	/** 검색 게시글 수 조회 Service
	 * @param condition
	 * @param boardType
	 * @return searchListCount
	 * @throws Exception
	 */
	public int getSearchListCount(String condition, int boardType) throws Exception {
		Connection conn = getConnection();
		
		int searchListCount = new BoardDao().getSearchListCount(conn, condition, boardType);
		
		close(conn);
		
		return searchListCount;
	}

	/** 검색 게시글 조회 Service
	 * @param currentPage
	 * @param limit
	 * @param boardType
	 * @param condition
	 * @return bList
	 * @throws Exception
	 */
	public List<Board> searchBoardList(int startRow, int endRow, int boardType, String condition) throws Exception{
		Connection conn = getConnection();
		
		List<Board> bList = new BoardDao().searchBoardList(conn, startRow, endRow, boardType, condition);
		
		close(conn);
		
		return bList;
	}

	/** 검색 게시글 파일 조회 Service
	 * @param currentPage
	 * @param limit
	 * @param boardType
	 * @param condition
	 * @return aList
	 * @throws Exception
	 */
	public List<Attachment> searchAList(int startRow, int endRow, int boardType, String condition) throws Exception{
		Connection conn = getConnection();
		
		List<Attachment> aList = new BoardDao().searchAList(conn, startRow, endRow, boardType, condition);
		
		close(conn);
		return aList;
	}

	/** 검색 게시글 동물 조회 Service
	 * @param startRow
	 * @param endRow
	 * @param boardType
	 * @param condition
	 * @return animalList
	 * @throws Exception
	 */
	public List<Animal> searchAnimalList(int startRow, int endRow, int boardType, String condition) throws Exception {
		Connection conn = getConnection();
		
		List<Animal> animalList = new BoardDao().searchAnimalList(conn, startRow, endRow, boardType, condition);
		
		close(conn);
		return animalList;
	}
}
