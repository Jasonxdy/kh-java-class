package com.kh.semiproject.board.model.dao;

import static com.kh.semiproject.common.JDBCTemplate.*;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.kh.semiproject.board.model.vo.Animal;
import com.kh.semiproject.board.model.vo.Attachment;
import com.kh.semiproject.board.model.vo.Board;
import com.kh.semiproject.findBoard.model.dao.FindBoardDao;
import com.kh.semiproject.member.model.vo.Member;

public class BoardDao {
	
	private Properties prop = null;
	
	public BoardDao() throws Exception{
		String fileName = FindBoardDao.class.getResource("/com/kh/semiproject/sql/board/board-query.properties").getPath();
		
		prop = new Properties();
		prop.load(new FileReader(fileName));
	}

	/** 다음 게시글 번호 반환용 Dao
	 * @param conn
	 * @return boardNo
	 * @throws Exception
	 */
	public int selectNextBoardNo(Connection conn) throws Exception {
		Statement stmt = null;
		ResultSet rset = null;
		int boardNo = 0;
		
		String query = prop.getProperty("selectNextBoardNo");
		
		try {
			stmt = conn.createStatement();
			rset = stmt.executeQuery(query);
			
			if(rset.next()) {
				boardNo = rset.getInt(1);
			}
		} finally {
			close(rset);
			close(stmt);
		}
		
		return boardNo;
	}
	
	/** 다음 동물 번호 반환용 Dao
	 * @param conn
	 * @return animalNo
	 * @throws Exception
	 */
	public int selectNextAnimalNo(Connection conn) throws Exception {
		Statement stmt = null;
		ResultSet rset = null;
		int animalNo = 0;
		
		String query = prop.getProperty("selectNextAnimalNo");
		
		try {
			stmt = conn.createStatement();
			rset = stmt.executeQuery(query);
			
			if(rset.next()) {
				animalNo = rset.getInt(1);
			}
		} finally {
			close(rset);
			close(stmt);
		}
		
		return animalNo;
	}
	
	/** 게시글 등록용  Dao
	 * @param conn
	 * @param board
	 * @return result
	 * @throws Exception
	 */
	public int insertBoard(Connection conn, Board board) throws Exception {
		PreparedStatement pstmt = null;
		int result = 0;
		
		String query = prop.getProperty("insertBoard");
		System.out.println(board);
		try {
			pstmt = conn.prepareStatement(query);
			
			pstmt.setInt(1, board.getBoardNo());
			pstmt.setString(2, board.getBoardTitle());
			pstmt.setString(3, board.getBoardContent());
			pstmt.setString(4, board.getBoardURL());
			pstmt.setString(5, board.getBoardWriter());
			pstmt.setInt(6, board.getBoardCode());
			
			result = pstmt.executeUpdate();
		} finally {
			close(pstmt);
		}
		
		return result;
	}
	
	/** 동물 코드 삽입용 Dao
	 * @param conn
	 * @param animal
	 * @return result
	 * @throws Exception
	 */
	public int insertAnimal(Connection conn, Animal animal) throws Exception {
		PreparedStatement pstmt = null;
		int result = 0;
		
		String query = prop.getProperty("insertAnimal");
		
		try {
			pstmt = conn.prepareStatement(query);
			
			pstmt.setInt(1, animal.getAnimalCode());
			pstmt.setString(2, animal.getAnimalGender());
			pstmt.setString(3, animal.getAnimalType());
			pstmt.setString(4, animal.getAnimalBreed());
			
			result = pstmt.executeUpdate();
		} finally {
			close(pstmt);
		}
		
		return result;
	}
	
	/** 게시글 파일(이미지) 정보 삽입용 Dao
	 * @param conn
	 * @param file
	 * @return result
	 * @throws Exception
	 */
	public int insertAttachment(Connection conn, Attachment file) throws Exception {
		PreparedStatement pstmt = null;
		int result = 0;
		String query = prop.getProperty("insertAttachment");
		
		try {
			pstmt = conn.prepareStatement(query);
			
			pstmt.setString(1, file.getFileOriginName());
			pstmt.setString(2, file.getFileChangeName());
			pstmt.setString(3, file.getFilePath());
			pstmt.setInt(4, file.getFileLevel());
			pstmt.setInt(5, file.getBoardNo());
			
			result = pstmt.executeUpdate();
		} finally {
			close(pstmt);
		}
		return result;
	}

	/** 전체 게시글 수 조회용 Dao
	 * @param conn
	 * @return listCount
	 * @throws Exception
	 */
	public int getListCount(Connection conn,int boardType) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		int listCount = 0;
		String query = prop.getProperty("getListCount");
		
		try {
			pstmt = conn.prepareStatement(query);
			
			pstmt.setInt(1, boardType);
			
			rset = pstmt.executeQuery();
			
			if(rset.next()) {
				listCount = rset.getInt(1); 
			}
		} finally {
			close(rset);
			close(pstmt);
		}
		return listCount;
	}
	
	/** 게시판 목록 조회용 Dao
	 * @param conn
	 * @param currentPage
	 * @param limit
	 * @return bList
	 * @throws Exception
	 */
	public List<Board> selectFList(Connection conn, int currentPage, int limit, int boardType) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		List<Board> bList = null;
		
		String query = prop.getProperty("selectFList");
		
		try {
			// 쿼리문 실행 시 between 조건에 사용될 값
			int startRow = (currentPage -1) * limit + 1;
			int endRow = startRow + limit -1;
			
			pstmt=conn.prepareStatement(query);
			
			pstmt.setInt(1, boardType);
			pstmt.setInt(2, startRow);
			pstmt.setInt(3, endRow);
			
			rset = pstmt.executeQuery();
			
			bList = new ArrayList<Board>();
			Board board = null;
			
			while(rset.next()) {
				board = new Board(rset.getInt("BOARD_NO"),
								rset.getString("BOARD_TITLE")
						);
				bList.add(board);
			}
		} finally {
			close(rset);
			close(pstmt);
		}
		
		return bList;
	}
	
	/** 썸네일 이미지 목록 조회 Dao
	 * @param conn
	 * @param currentPage
	 * @param limit
	 * @return fList
	 * @throws Exception
	 */
	public List<Attachment> selectAList(Connection conn, int currentPage, int limit, int boardType) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		ArrayList<Attachment> aList = null;
		
		String query = prop.getProperty("selectAList");
		
		try {
			// 쿼리문 실행 시 between 조건에 사용될 값
			int startRow = (currentPage -1) * limit + 1;
			int endRow = startRow + limit -1;
			
			pstmt=conn.prepareStatement(query);
			
			pstmt.setInt(1, boardType);
			pstmt.setInt(2, startRow);
			pstmt.setInt(3, endRow);
			
			rset = pstmt.executeQuery();
			
			aList = new ArrayList<Attachment>();
			Attachment file = null;
			
			while(rset.next()) {
				file = new Attachment();
				file.setFileNo(rset.getInt("IMG_NO"));
				file.setBoardNo(rset.getInt("BOARD_NO"));
				file.setFileChangeName(rset.getString("IMG_CHANGE_NAME"));
				file.setFileStatus(rset.getString("IMG_STATUS"));
				
				aList.add(file);
			}
		} finally {
			close(rset);
			close(pstmt);
		}
		
		return aList;
	}

	/** 목록 조회용 동물 정보 반환 Dao
	 * @param conn
	 * @param currentPage
	 * @param limit
	 * @param boardType
	 * @return animalList
	 * @throws Exception
	 */
	public List<Animal> selectAnimalList(Connection conn, int currentPage, int limit, int boardType) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		ArrayList<Animal> animalList = null;
		
		String query = prop.getProperty("selectAnimalList");
		
		try {
			int startRow = (currentPage -1) * limit + 1;
			int endRow = startRow + limit -1;
			
			pstmt=conn.prepareStatement(query);
			
			pstmt.setInt(1, boardType);
			pstmt.setInt(2, startRow);
			pstmt.setInt(3, endRow);
			
			rset = pstmt.executeQuery();
			
			animalList = new ArrayList<Animal>();
			Animal animal = null;
			
			while(rset.next()) {
				animal = new Animal();
				animal.setAnimalCode(rset.getInt("ANIMAL_CODE"));
				animal.setAnimalGender(rset.getString("ANIMAL_GENDER"));
				animal.setAnimalType(rset.getString("ANIMAL_TYPE"));
				animal.setAnimalBreed(rset.getString("ANIMAL_BREED"));
				animal.setAnimalStatus(rset.getString("ANIMAL_STATUS"));
				
				animalList.add(animal);
			}
		} finally {
			close(rset);
			close(pstmt);
		}
		
		return animalList;
	}

	/** 게시글 상세 조회용 Dao
	 * @param conn
	 * @param boardNo
	 * @return board
	 * @throws Exception
	 */
	public Board selectboard(Connection conn, int boardNo) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		Board board = null;
		
		String query = prop.getProperty("selectBoard");
		
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, boardNo);
			rset = pstmt.executeQuery();
			
			if(rset.next()) {
				board = new Board(boardNo, rset.getString("BOARD_TITLE"),
						rset.getString("BOARD_CONTENT"),
						rset.getInt("BOARD_COUNT"),
						rset.getDate("BOARD_MODIFY_DT"),
						rset.getString("BOARD_URL"),
						rset.getString("MEM_ID"),
						rset.getInt("BOARD_CODE"));
			}
		} finally {
			close(rset);
			close(pstmt);
		}
		
		return board;
	}

	/** 게시글 이미지 파일 조회용 Dao
	 * @param conn
	 * @param boardNo
	 * @return files
	 * @throws Exception
	 */
	public List<Attachment> selectFiles(Connection conn, int boardNo) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		ArrayList<Attachment> files = null;
		
		String query = prop.getProperty("selectFiles");
		
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, boardNo);
			
			rset = pstmt.executeQuery();
			
			files = new ArrayList<Attachment>();
			Attachment file = null;
			
			while(rset.next()) {
				file = new Attachment(rset.getInt("IMG_NO"),
										rset.getInt("BOARD_NO"), 
										rset.getString("IMG_ORIGIN_NAME"),
										rset.getString("IMG_CHANGE_NAME"),
										rset.getString("IMG_PATH"),
										rset.getDate("IMG_CREATE_DT"),
										rset.getInt("IMG_LEVEL"),
										rset.getString("IMG_STATUS"));
				
				files.add(file);
			}
		} finally {
			close(rset);
			close(pstmt);
		}
		
		return files;
	}

	/** 게시글 동물 조회용 Dao
	 * @param conn
	 * @param animalCode
	 * @return animal
	 * @throws Exception
	 */
	public Animal selectAnimal(Connection conn, int animalCode) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		Animal animal = null;
		
		String query = prop.getProperty("selectAnimal");
		
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, animalCode);
			rset= pstmt.executeQuery();
			
			if(rset.next()) {
				animal = new Animal(animalCode,
						rset.getString("ANIMAL_GENDER"),
						rset.getString("ANIMAL_TYPE"),
						rset.getString("ANIMAL_BREED"));
			}
		} finally {
			close(rset);
			close(pstmt);
		}
		
		return animal;
	}

	/** 게시글 삭제용 Dao
	 * @param conn
	 * @param no
	 * @return result
	 * @throws Exception
	 */
	public int deleteBoard(Connection conn, int no) throws Exception {
		PreparedStatement pstmt = null;
		int result = 0;
		String query = prop.getProperty("deleteBoard");
		
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, no);
			
			result = pstmt.executeUpdate();
		} finally {
			close(pstmt);
		}
		
		return result;
	}

	/** 사진 삭제용 Dao
	 * @param conn
	 * @param no
	 * @return result
	 * @throws Exception
	 */
	public int deleteAttachment(Connection conn, int no) throws Exception {
		PreparedStatement pstmt = null;
		int result = 0;
		String query = prop.getProperty("deleteAttachment");
		
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, no);
			
			result = pstmt.executeUpdate();
		} finally {
			close(pstmt);
		}
		
		return result;
	}

	/** 동물코드 삭제용 Dao
	 * @param conn
	 * @param no
	 * @return result
	 * @throws Exception
	 */
	public int deleteAnimal(Connection conn, int no) throws Exception {
		PreparedStatement pstmt = null;
		int result = 0;
		String query = prop.getProperty("deleteAnimal");
		
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, no);
			
			result = pstmt.executeUpdate();
		} finally {
			close(pstmt);
		}
		
		return result;
	}
	
	
	/** 게시판 수정용 Dao
	 * @param conn
	 * @param board
	 * @return result
	 * @throws Exception
	 */
	public int updateBoard(Connection conn, Board board) throws Exception {
		PreparedStatement pstmt = null;
		int result = 0;
		String query = prop.getProperty("updateBoard");
		
		try {
			pstmt = conn.prepareStatement(query);
			
			pstmt.setString(1, board.getBoardTitle());
			pstmt.setString(2, board.getBoardContent());
			pstmt.setString(3, board.getBoardURL());
			pstmt.setInt(4, board.getBoardNo());
			
			result = pstmt.executeUpdate();
		} finally {
			close(pstmt);
		}
		
		return result;
	}
	
	/** 동물 수정용 Dao
	 * @param conn
	 * @param animal
	 * @return result
	 * @throws Exception
	 */
	public int updateAnimal(Connection conn, Animal animal, int boardNo) throws Exception {
		PreparedStatement pstmt = null;
		int result = 0;
		String query = prop.getProperty("updateAnimal");
		
		try {
			pstmt = conn.prepareStatement(query);
			
			pstmt.setString(1, animal.getAnimalGender());
			pstmt.setString(2, animal.getAnimalType());
			pstmt.setString(3, animal.getAnimalBreed());
			pstmt.setInt(4, boardNo);
			
			result = pstmt.executeUpdate();
		} finally {
			close(pstmt);
		}
		
		return result;
	}

	/** 썸네일 삭제용 Dao
	 * @param conn
	 * @param boardNo
	 * @return result
	 * @throws Exception
	 */
	public int deleteThumbnail(Connection conn, int boardNo) throws Exception {
		PreparedStatement pstmt = null;
		int result = 0;
		String query = prop.getProperty("deleteThumbnail");
		
		try {
			pstmt = conn.prepareStatement(query);
			
			pstmt.setInt(1, boardNo);
			
			result = pstmt.executeUpdate();
		} finally {
			close(pstmt);
		}
		
		return result;
	}

	/** 이미지 파일 카운트용 Dao
	 * @param conn
	 * @param boardNo
	 * @return count
	 * @throws Exception
	 */
	public int countAttachment(Connection conn, int boardNo) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		int count = 0;
		String query = prop.getProperty("countAttachment");
		
		try {
			pstmt = conn.prepareStatement(query);
			
			pstmt.setInt(1, boardNo);
			
			rset = pstmt.executeQuery();
			
			if(rset.next()) {
				count = rset.getInt(1);
			}
		} finally {
			close(rset);
			close(pstmt);
		}
		
		return count;
	}

	/** 일반 이미지 삭제용 Dao
	 * @param conn
	 * @param boardNo
	 * @return result
	 * @throws Exception
	 */
	public int deleteImg(Connection conn, int boardNo, int over) throws Exception {
		PreparedStatement pstmt = null;
		int result = 0;
		String query = prop.getProperty("deleteImg");
		
		try {
			pstmt = conn.prepareStatement(query);
			
			pstmt.setInt(1, boardNo);
			pstmt.setInt(2, over);
			
			result = pstmt.executeUpdate();
		} finally {
			close(pstmt);
		}
		
		return result;
	}

	/** 검색 게시글 수 조회용 Dao
	 * @param conn
	 * @param boardType
	 * @return searchListCount
	 * @throws Exception
	 */
	public int getSearchListCount(Connection conn, String condition, int boardType) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		int searchListCount = 0;
		String query = prop.getProperty("getSearchListCount");
		
		try {
			pstmt = conn.prepareStatement(query + condition);
			
			pstmt.setInt(1, boardType);
			
			rset = pstmt.executeQuery();
			
			if(rset.next()) {
				searchListCount = rset.getInt(1); 
			}
		} finally {
			close(rset);
			close(pstmt);
		}
		return searchListCount;
	}

	/** 게시글 검색 조회용 Service
	 * @param conn
	 * @param currentPage
	 * @param limit
	 * @param boardType
	 * @param condition
	 * @return bList
	 * @throws Exception
	 */
	public List<Board> searchBoardList(Connection conn, int startRow, int endRow, int boardType, String condition) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		List<Board> bList = null;
		
		String query1 = prop.getProperty("searchBoardList1");
		String query2 = prop.getProperty("searchBoardList2");
		
		try {
			pstmt = conn.prepareStatement(query1+condition+query2);
			
			rset = pstmt.executeQuery();
			
			bList = new ArrayList<Board>();
			Board board = null;
			
			while(rset.next()) {
				board = new Board(rset.getInt("BOARD_NO"), 
								rset.getString("BOARD_TITLE"), 
								rset.getInt("BOARD_COUNT"), 
								rset.getDate("BOARD_MODIFY_DT"), 
								rset.getString("MEM_NAME"), 
								rset.getInt("BOARD_CODE"));
				
				bList.add(board);
			}
		} finally {
			close(rset);
			close(pstmt);
		}
		
		return bList;
	}

	/** 검색 게시글 동물 조회용 Dao
	 * @param conn
	 * @param currentPage
	 * @param limit
	 * @param boardType
	 * @param condition
	 * @return aList
	 * @throws Exception
	 */
	public List<Attachment> searchAList(Connection conn, int startRow, int endRow, int boardType, String condition) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		ArrayList<Attachment> aList = null;
		
		String query1 = prop.getProperty("searchAList1");
		String query2 = prop.getProperty("searchAList2");
		
		try {
			pstmt = conn.prepareStatement(query1+condition+query2);
			
			pstmt.setInt(1, boardType);
			pstmt.setInt(2, startRow);
			pstmt.setInt(3, endRow);
			
			rset = pstmt.executeQuery();
			
			aList = new ArrayList<Attachment>();
			Attachment file = null;
			
			while(rset.next()) {
				file = new Attachment();
				file.setFileNo(rset.getInt("IMG_NO"));
				file.setBoardNo(rset.getInt("BOARD_NO"));
				file.setFileChangeName(rset.getString("IMG_CHANGE_NAME"));
				file.setFileStatus(rset.getString("IMG_STATUS"));
				
				aList.add(file);
			}
		} finally {
			close(rset);
			close(pstmt);
		}
		
		return aList;
	}

	/** 검색 게시글 동물 조회용 Dao
	 * @param conn
	 * @param startRow
	 * @param endRow
	 * @param boardType
	 * @param condition
	 * @return animalList
	 * @throws Exception
	 */
	public List<Animal> searchAnimalList(Connection conn, int startRow, int endRow, int boardType, String condition) throws Exception{
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		ArrayList<Animal> animalList = null;
		
		String query1 = prop.getProperty("searchAnimalList1");
		String query2 = prop.getProperty("searchAnimalList2");
		
		try {
			pstmt = conn.prepareStatement(query1+condition+query2);
			
			pstmt.setInt(1, boardType);
			pstmt.setInt(2, startRow);
			pstmt.setInt(3, endRow);
			
			rset = pstmt.executeQuery();
			
			animalList = new ArrayList<Animal>();
			Animal animal = null;
			
			while(rset.next()) {
				animal.setAnimalCode(rset.getInt("ANIMAL_CODE"));
				animal.setAnimalGender(rset.getString("ANIMAL_GENDER"));
				animal.setAnimalType(rset.getString("ANIMAL_TYPE"));
				animal.setAnimalBreed(rset.getString("ANIMAL_BREED"));
				animal.setAnimalStatus(rset.getString("ANIMAL_STATUS"));
				
				animalList.add(animal);
			}
		} finally {
			close(rset);
			close(pstmt);
		}
		
		return animalList;
	}
	
}
