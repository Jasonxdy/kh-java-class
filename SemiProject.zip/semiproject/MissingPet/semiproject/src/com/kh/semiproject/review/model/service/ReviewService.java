package com.kh.semiproject.review.model.service;


import static com.kh.semiproject.common.JDBCTemplate.*;

import java.sql.Connection;
import java.util.List;

import com.kh.semiproject.review.model.dao.ReviewDAO;
import com.kh.semiproject.review.model.vo.Review;

public class ReviewService {

	public int getListCount() throws Exception {
		Connection conn = getConnection();
		
		int listCount = new ReviewDAO().getListCount(conn);
		close(conn);
		return listCount;
	}

	public List<Review> selectList(int currentPage, int limit) throws Exception {
		Connection conn = getConnection();
		
		List<Review> rList = new ReviewDAO().selectList(conn, currentPage, limit);
		
		close(conn);
		return rList;
	}

}
