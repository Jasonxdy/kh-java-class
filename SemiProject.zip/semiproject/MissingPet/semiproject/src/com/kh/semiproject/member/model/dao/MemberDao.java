package com.kh.semiproject.member.model.dao;

import static com.kh.semiproject.common.JDBCTemplate.*;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;

import com.kh.semiproject.member.model.vo.Member;

public class MemberDao {
	
	private Properties prop = null;
	
	public MemberDao() throws Exception {
		
		String fileName = MemberDao.class.getResource("/com/kh/semiproject/sql/member/member-query.properties").getPath();
		
		prop = new Properties();
		prop.load(new FileReader(fileName));
	}

	public Member loginMember(Connection conn, Member member) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		
		Member loginMember = null;
		
		String query = prop.getProperty("loginMember");
		
		
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, member.getMemberId());
			pstmt.setString(2, member.getMemberPwd());
			rset = pstmt.executeQuery();
			
			if(rset.next()) {
				String memberId = rset.getString("MEM_ID");
				String memberName = rset.getString("MEM_NAME");
				String memberEmail = rset.getString("MEM_EMAIL");
				String memberPhone = rset.getString("MEM_PHONE");
				String memberWebTell = rset.getString("MEM_WEB_TELL");;
				String memberCommentTell = rset.getString("MEM_COMMENT_TELL");
				String memberAskTell = rset.getString("MEM_ASK_TELL");;
				String memberRTTell = rset.getString("MEM_REALTIME_TELL");
				String memberEmailCertify = rset.getString("MEM_EMAIL_CERTIFY");
				String memberStatus = rset.getString("MEM_STATUS");
				String memberGrade = rset.getString("MEM_GRADE");
				Date memberSignUpDT = rset.getDate("MEM_SIGNUP_DT");
				String memberProImg = rset.getString("MEM_PRO_IMG");
				
				loginMember = new Member(memberId, memberName, memberEmail,
						memberPhone, memberWebTell, memberCommentTell, memberAskTell,
						memberRTTell, memberEmailCertify, memberStatus, memberGrade,
						memberSignUpDT, memberProImg);
			}
			
		} finally {
			close(rset);
			close(pstmt);
		}
		
		return loginMember;
	}
	
	public int idDupCheck(Connection conn, String id) throws Exception {
		int result = 0;
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		String query = prop.getProperty("idDupCheck");
		
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, id);
			
			rset = pstmt.executeQuery();
			
			if(rset.next()) {
				result = rset.getInt(1);
			}
		}finally {
			close(rset);
			close(pstmt);
		}
		
		return result;
	}

	public int signUp(Connection conn, Member member) throws Exception {
		PreparedStatement pstmt = null;
		int result = 0;
		String query = prop.getProperty("signUp");
		
		try {
			pstmt = conn.prepareStatement(query);
			
			pstmt.setString(1, member.getMemberId());
			pstmt.setString(2, member.getMemberName());
			pstmt.setString(3, member.getMemberPwd());
			pstmt.setString(4, member.getMemberEmail());
			pstmt.setString(5, member.getMemberPhone());
			pstmt.setString(6, member.getMemberProImg());
			
			result = pstmt.executeUpdate();
		}finally {
			close(pstmt);
		}
		
		return result;
	}

}
