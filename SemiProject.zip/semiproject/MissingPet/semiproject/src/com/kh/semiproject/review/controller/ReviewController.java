package com.kh.semiproject.review.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kh.semiproject.common.ExceptionForward;
import com.kh.semiproject.review.model.service.ReviewService;
import com.kh.semiproject.review.model.vo.Img;
import com.kh.semiproject.review.model.vo.PageInfo;
import com.kh.semiproject.review.model.vo.Review;

@WebServlet("/review/*")
public class ReviewController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ReviewController() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ReviewService reviewService = new ReviewService();
		String uri = request.getRequestURI();
		String contextPath = request.getContextPath();
		String command = uri.substring((contextPath+"/member").length());
		
		String msg = null;
		String path = null;
		RequestDispatcher view = null;
		
		if(command.equals("/reviewList")) {
			try {
				int listCount = reviewService.getListCount();
				
				int limit = 5;
				int pagingBarSize = 5;
				
				int currentPage = 0;
				int maxPage = 0;
				int startPage = 0;
				int endPage = 0;
				
				if(request.getParameter("currentPage") == null) {
					currentPage = 1;
				}else {
					currentPage = Integer.parseInt(request.getParameter("currentPage"));
				}
				maxPage = (int)Math.ceil(((double)listCount / limit));
				
				startPage = (currentPage-1) / pagingBarSize * pagingBarSize + 1;
				endPage = startPage + pagingBarSize - 1;
				if(maxPage <= endPage) {
					endPage = maxPage;
				}
				PageInfo pInf = new PageInfo(listCount, limit, pagingBarSize,
						currentPage, maxPage, startPage, endPage);
				
//				List<Review> rList = reviewService.selectList(currentPage, limit);
//				List<Img> iList = reviewService.selectImgList(currentPage, limit);
				
				path = "/WEB-INF/views/review/reviewList.jsp";
//				request.setAttribute("rList", rList);
				request.setAttribute("pInf", pInf);
//				request.setAttribute("iList", iList);
				
				view = request.getRequestDispatcher(path);
				view.forward(request, response);
				
			}catch (Exception e) {
				ExceptionForward.errorPage(request, response, "만남 그 후 목록 조회", e);
			}
			
//			path = "/WEB-INF/views/review/reviewList.jsp";
//			view = request.getRequestDispatcher(path);
//			view.forward(request, response);
		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
