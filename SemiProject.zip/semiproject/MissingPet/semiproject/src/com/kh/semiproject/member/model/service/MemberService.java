package com.kh.semiproject.member.model.service;

import static com.kh.semiproject.common.JDBCTemplate.*;

import java.sql.Connection;

import com.kh.semiproject.member.model.dao.MemberDao;
import com.kh.semiproject.member.model.vo.Member;

public class MemberService {

	/** 로그인용 Service
	 * @param member
	 * @return member
	 * @throws Exception
	 */
	public Member loginMember(Member member) throws Exception {
		Connection conn = getConnection();
		
		Member loginMember = new MemberDao().loginMember(conn, member);
		
		return loginMember;
	}

	public int idDupCheck(String id) throws Exception {
		Connection conn = getConnection();
		
		
		return new MemberDao().idDupCheck(conn, id);
	}

	public int signUp(Member member) throws Exception {
		Connection conn = getConnection();
		
		int result = new MemberDao().signUp(conn, member);
		if(result>0) commit(conn);
		else rollback(conn);
		System.out.println("서비스");
		close(conn);
		return result;
	}

}
