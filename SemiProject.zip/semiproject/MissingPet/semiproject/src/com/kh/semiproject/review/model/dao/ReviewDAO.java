package com.kh.semiproject.review.model.dao;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;
import java.util.Properties;

import com.kh.semiproject.review.model.vo.Review;

import static com.kh.semiproject.common.JDBCTemplate.*;

public class ReviewDAO {
	private Properties prop = null;
	
	public ReviewDAO() throws Exception {
		
		String fileName = ReviewDAO.class.getResource("/com/kh/semiproject/sql/review/review-query.properties").getPath();
		
		prop = new Properties();
		prop.load(new FileReader(fileName));
	}

	public int getListCount(Connection conn) throws Exception {
		int listCount = 0;
		
		Statement stmt = null;
		ResultSet rset = null;
		String query = prop.getProperty("getListCount");
		
		try {
			stmt = conn.createStatement();
			rset = stmt.executeQuery(query);
			
			if(rset.next()) {
				listCount = rset.getInt(1);
			}
		}finally {
			close(rset);
			close(stmt);
		}
		
		return listCount;
	}

	public List<Review> selectList(Connection conn, int currentPage, int limit)
		throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		List<Review> rList = null;
		
		String query = prop.getProperty("selectList");
		
		try {
			pstmt = conn.prepareStatement(query);
			
			
		}finally {
			
		}
		
		return null;
	}
	
	
}
