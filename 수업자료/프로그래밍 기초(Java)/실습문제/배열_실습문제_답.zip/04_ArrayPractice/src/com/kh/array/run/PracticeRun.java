package com.kh.array.run;

import com.kh.array.practice.ArrayPractice;

public class PracticeRun {
	public static void main(String[] args) {
		ArrayPractice ap = new ArrayPractice();
		
		ap.practice15();
	}
}
