package com.kh.bingo.run;

import com.kh.bingo.view.BingoMenu;

public class BingoRun {
	public static void main(String[] args) {
		new BingoMenu().mainMenu();
	}
}
