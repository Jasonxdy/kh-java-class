package com.kh.practice.run;

import com.kh.practice.dimension.DimensionPractice;

public class Run {
	public static void main(String[] args) {
		DimensionPractice dp = new DimensionPractice();
		//dp.practice1();
		//dp.practice2();
		//dp.practice3();
		//dp.practice4();
		//dp.practice5();
		//dp.practice6();
		//dp.practice7();
		//dp.practice8();
		//dp.practice9();
		dp.practice10();
		//dp.practice11();
	}
}
