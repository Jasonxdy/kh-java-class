package com.kh.chap01_poly.practice.run;

import com.kh.chap01_poly.practice.view.LibraryMenu;

public class Run {
	public static void main(String[] args) {
		new LibraryMenu().mainMenu();
	}
}
