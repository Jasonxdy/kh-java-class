package com.kh.chap02_ab_In.practice.model.vo;

public interface TouchDisplay {
	String touch();
}
