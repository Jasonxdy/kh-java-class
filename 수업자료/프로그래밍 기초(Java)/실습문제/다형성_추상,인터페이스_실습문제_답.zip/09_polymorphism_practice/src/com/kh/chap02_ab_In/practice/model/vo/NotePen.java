package com.kh.chap02_ab_In.practice.model.vo;

public interface NotePen {
	boolean PEN_BUTTON = true;
	boolean bluetoothPen();
}
